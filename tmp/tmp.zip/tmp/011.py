scope = [1,2,3,4,5]
for x in scope:
    print(x)

str = 'abcdef'
for c in str:
    print(c)

list = [1,2,3,4,5]
for c in list:
    print(c)


ascii_codes = {'a':97, 'b':98, 'c':99}
for c in ascii_codes:
    print(c)

for c in range(10):
    print(c)
